import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { redirect } from "next/navigation"
import { PromoBanner } from "@/components/promo-banner"
import { VideoPlayer } from "@/components/video-player"
import Image from "next/image"
import Link from "next/link"

export default async function DashboardPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const paypalUpgradeUrl =
    "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=earndaily101@mail.com&currency_code=USD&amount=497&item_name=DigiMark101%20Enterprise%20Upgrade"

  return (
    <div className="grid gap-4 p-4 md:gap-8 md:p-8">
      <PromoBanner />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-4">
          <div className="rounded-xl border bg-card text-card-foreground shadow">
            <div className="p-6 flex flex-col gap-4">
              <h3 className="text-2xl font-semibold leading-none tracking-tight">Welcome Back!</h3>
              <p className="text-sm text-muted-foreground">
                Watch this quick update from Ava Skye about your account performance.
              </p>
              <VideoPlayer
                thumbnailSrc="/images/ava-skye-welcome.jpg"
                title="Weekly Update with Ava Skye"
                alt="Ava Skye AI Assistant Welcome"
              />
            </div>
          </div>
        </div>

        <div className="col-span-3">
          <div className="rounded-xl border bg-card text-card-foreground shadow h-full">
            <div className="p-6 flex flex-col gap-4 h-full">
              <h3 className="text-xl font-semibold">Ava Skye - Enterprise Edition</h3>
              <div className="relative aspect-square w-full overflow-hidden rounded-lg">
                <Image
                  src="/images/ava-skye-enterprise.jpg"
                  alt="Ava Skye Enterprise Version"
                  fill
                  className="object-cover"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Upgrade to Enterprise to unlock the advanced capabilities of Ava Skye for automated campaign management.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-3">
          <div className="rounded-xl border bg-card text-card-foreground shadow h-full">
            <div className="p-6 flex flex-col gap-4 h-full">
              <h3 className="text-xl font-semibold">Ava Skye - Creative Director</h3>
              <div className="relative aspect-square w-full overflow-hidden rounded-lg">
                <Image
                  src="/images/ava-skye-creative.jpg"
                  alt="Ava Skye Creative Director Version"
                  fill
                  className="object-cover"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Need help with ad creatives? Switch to the Creative Director persona for expert design advice and copy
                generation.
              </p>
              <Button variant="outline" className="w-full bg-transparent" asChild>
                <Link href={paypalUpgradeUrl} target="_blank">
                  Upgrade to Access
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="col-span-4">
          <div className="rounded-xl border bg-card text-card-foreground shadow h-full">
            <div className="p-6 flex flex-col gap-4 h-full">
              <h3 className="text-xl font-semibold">Ava Skye - Elite Consultant</h3>
              <div className="relative aspect-video w-full overflow-hidden rounded-lg">
                <Image
                  src="/images/ava-skye-v3.jpg"
                  alt="Ava Skye Elite Consultant Version"
                  fill
                  className="object-cover"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Meet the new Elite Consultant version of Ava Skye. With enhanced predictive analytics and a more
                personable interface, she is ready to take your business to the next level.
              </p>
              <Button className="w-full" asChild>
                <Link href={paypalUpgradeUrl} target="_blank">
                  Activate Elite Mode
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <Button>New Request</Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Account Status</CardTitle>
            <CardDescription>Your current subscription status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Active</div>
            <p className="text-xs text-muted-foreground">Standard Plan</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Active Services</CardTitle>
            <CardDescription>Services currently running</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">Done For You Campaigns</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Support</CardTitle>
            <CardDescription>Need help?</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full bg-transparent">
              Contact Support
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
