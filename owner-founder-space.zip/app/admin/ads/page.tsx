import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function AdsPage() {
  return (
    <div className="grid gap-4 p-4 md:gap-8 md:p-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Ad Management</h1>
          <p className="text-muted-foreground">Manage platform advertising and affiliate links</p>
        </div>
        <Button>Create Campaign</Button>
      </div>

      <Tabs defaultValue="affiliate" className="space-y-4">
        <TabsList>
          <TabsTrigger value="platform">Platform Ads</TabsTrigger>
          <TabsTrigger value="affiliate">Affiliate Networks</TabsTrigger>
          <TabsTrigger value="requests">Client Requests</TabsTrigger>
        </TabsList>

        <TabsContent value="platform" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Internal Campaigns</CardTitle>
              <CardDescription>Ads promoting this platform</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border p-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h3 className="font-medium">Main Landing Page Retargeting</h3>
                    <p className="text-sm text-muted-foreground">Active • $50/day budget</p>
                  </div>
                  <Button variant="outline">Edit</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="affiliate" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Top5survivalgoods Integration</CardTitle>
                <CardDescription>Manage the promo banner on client dashboard</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Banner Title</Label>
                  <Input defaultValue="Top 5 Survival Goods" />
                </div>
                <div className="space-y-2">
                  <Label>Target URL</Label>
                  <Input defaultValue="https://top5survivalgoods.com" />
                </div>
                <div className="flex items-center gap-2">
                  <Button>Update Banner</Button>
                  <Button variant="outline">Preview</Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Affiliate Stats</CardTitle>
                <CardDescription>Performance metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Clicks (Last 30 days)</span>
                    <span className="font-bold">1,234</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Conversions</span>
                    <span className="font-bold">45</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Est. Revenue</span>
                    <span className="font-bold text-green-600">$450.00</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
