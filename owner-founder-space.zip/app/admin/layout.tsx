import type React from "react"
import type { Metadata } from "next"
import { AdminNav } from "@/components/admin-nav"
import { SiteHeader } from "@/components/site-header"

export const metadata: Metadata = {
  title: "Founder Admin",
  description: "Manage your business",
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <div className="container flex-1 items-start md:grid md:grid-cols-[220px_minmax(0,1fr)] md:gap-6 md:py-6">
        <aside className="fixed top-14 z-30 -ml-2 hidden h-[calc(100vh-3.5rem)] w-full shrink-0 overflow-y-auto border-r md:sticky md:block bg-slate-50 dark:bg-slate-950">
          <div className="p-4 font-bold text-lg text-primary">Founder Space</div>
          <AdminNav />
        </aside>
        <main className="flex w-full flex-col overflow-hidden">{children}</main>
      </div>
    </div>
  )
}
