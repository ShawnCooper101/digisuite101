import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"

export function PromoBanner() {
  return (
    <Card className="bg-gradient-to-r from-amber-500 to-orange-600 text-white border-none">
      <CardContent className="flex flex-col md:flex-row items-center justify-between p-6 gap-4">
        <div className="space-y-2">
          <h3 className="text-xl font-bold">Top 5 Survival Goods</h3>
          <p className="text-amber-100">
            Check out our partner site for the best survival gear reviews and deals. Exclusive offers for our members!
          </p>
        </div>
        <Button asChild variant="secondary" className="whitespace-nowrap">
          <Link href="https://top5survivalgoods.com" target="_blank" rel="noopener noreferrer">
            Visit Site <ExternalLink className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}
