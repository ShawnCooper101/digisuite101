import Link from "next/link"
import Image from "next/image"

export function SiteFooter() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl">
              <div className="relative h-8 w-8 overflow-hidden rounded-lg">
                <Image src="/images/logo-v2.jpg" alt="DigiMark101 Logo" fill className="object-cover" />
              </div>
              <span>DigiMark101</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Empowering founders with enterprise-grade tools and Done-For-You services.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Platform</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-foreground">
                  Client Portal
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Founder Dashboard
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Ad Management
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Affiliate Network
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-foreground">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Legal
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Partners</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-foreground">
                  Top5survivalgoods
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Cellphone Cash
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Become a Partner
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} DigiMark101. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
