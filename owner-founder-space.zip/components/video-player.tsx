import { Play } from "lucide-react"
import Image from "next/image"

interface VideoPlayerProps {
  thumbnailSrc: string
  title: string
  alt: string
}

export function VideoPlayer({ thumbnailSrc, title, alt }: VideoPlayerProps) {
  return (
    <div className="relative aspect-video w-full overflow-hidden rounded-xl border bg-muted shadow-xl">
      <Image src={thumbnailSrc || "/placeholder.svg"} alt={alt} fill className="object-cover" />
      <div className="absolute inset-0 flex items-center justify-center bg-black/20 transition-colors hover:bg-black/30 group cursor-pointer">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-background/90 shadow-lg transition-transform group-hover:scale-110">
          <Play className="h-8 w-8 fill-foreground text-foreground ml-1" />
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
      </div>
    </div>
  )
}
