import { Button } from "@/components/ui/button"
import { ArrowRight, CheckCircle2 } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden pt-16 md:pt-24 lg:pt-32 pb-16">
      <div className="container relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-24 items-center">
          <div className="flex flex-col gap-6">
            <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80 w-fit">
              New: Enterprise Founder Dashboard
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-balance">
              Scale Your Business with <span className="text-primary">Done-For-You</span> Excellence
            </h1>
            <p className="text-lg text-muted-foreground text-balance max-w-xl">
              We handle the complexities of scaling while you focus on vision. From ad management to full-service client
              operations, we provide the infrastructure for growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-4">
              <Button size="lg" className="gap-2" asChild>
                <Link href="#pricing">
                  Start Your Growth <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline">
                View Demo
              </Button>
            </div>
            <div className="flex items-center gap-6 mt-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <span>Verified Results</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <span>24/7 Support</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <span>Full Transparency</span>
              </div>
            </div>
          </div>
          <div className="relative lg:h-[600px] w-full hidden lg:block">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent rounded-3xl blur-3xl" />
            <div className="relative h-full w-full rounded-2xl border bg-background/50 backdrop-blur-sm shadow-2xl overflow-hidden p-2">
              <Image
                src="/placeholder.svg?height=600&width=800"
                alt="Dashboard Preview"
                width={800}
                height={600}
                className="rounded-xl object-cover w-full h-full border shadow-sm"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
