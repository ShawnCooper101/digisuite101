import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import Link from "next/link"

export function PricingSection() {
  const paypalEmail = "earndaily101@mail.com"

  const plans = [
    {
      name: "DIY Starter",
      price: "97",
      description: "Perfect for self-starters who want full control",
      features: [
        "Access to Ava Skye AI Assistant",
        "DIY Ad Management Tools",
        "Weekly Performance Reports",
        "Email Support",
        "Client Dashboard Access",
        "Basic Marketing Templates",
      ],
      item_name: "DigiMark101 DIY Starter",
    },
    {
      name: "DIY Pro",
      price: "197",
      description: "Advanced tools for growing businesses",
      features: [
        "Everything in DIY Starter",
        "Creative Director Persona Access",
        "Advanced Ad Analytics",
        "Daily Performance Reports",
        "24/7 Priority Support",
        "Custom Ad Creative Templates",
        "A/B Testing Tools",
      ],
      item_name: "DigiMark101 DIY Pro",
      popular: true,
    },
    {
      name: "DFY Elite Service",
      price: "497",
      description: "We handle everything for you",
      features: [
        "Everything in DIY Pro",
        "Elite Consultant Persona Access",
        "Dedicated Account Manager",
        "Done-For-You Campaign Setup",
        "Complete Ad Management",
        "White-label Reporting",
        "Monthly Strategy Calls",
        "Hands-free Optimization",
      ],
      item_name: "DigiMark101 DFY Elite Service",
    },
  ]

  return (
    <section id="pricing" className="py-24 bg-muted/50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight">Choose Your Path: DIY or DFY</h2>
          <p className="text-lg text-muted-foreground">
            Whether you want to manage it yourself with our powerful tools or have us handle everything, we have a plan
            for you.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative flex flex-col p-8 bg-background rounded-2xl border ${
                plan.popular ? "border-primary shadow-lg scale-105 z-10" : "border-border shadow-sm"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary text-primary-foreground text-sm font-medium rounded-full">
                  Most Popular
                </div>
              )}

              <div className="mb-8">
                <h3 className="text-xl font-bold">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mt-2">{plan.description}</p>
                <div className="mt-6 flex items-baseline gap-1">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
              </div>

              <ul className="flex-1 space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm">
                    <Check className="h-5 w-5 text-primary shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <Button asChild className="w-full" variant={plan.popular ? "default" : "outline"}>
                <Link
                  href={`https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=${paypalEmail}&currency_code=USD&amount=${plan.price}&item_name=${encodeURIComponent(plan.item_name)}&return=${encodeURIComponent("https://digimark101.com/dashboard")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Get Started
                </Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
