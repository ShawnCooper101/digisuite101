import { BarChart3, Globe, Shield, Users, Zap, Wallet } from "lucide-react"

const features = [
  {
    title: "Done-For-You Advertising",
    description:
      "Expertly managed ad campaigns that drive real ROI. We handle the creative, targeting, and optimization.",
    icon: BarChart3,
  },
  {
    title: "Client Portal Access",
    description:
      "Give your clients a professional home. View account settings, track progress, and access support in one place.",
    icon: Users,
  },
  {
    title: "Founder Dashboard",
    description:
      "Complete oversight of your empire. Manage DFY accounts, track affiliate performance, and control advertising.",
    icon: Shield,
  },
  {
    title: "Affiliate Integration",
    description:
      "Seamlessly connect with Top5survivalgoods and other affiliate networks to maximize your revenue streams.",
    icon: Globe,
  },
  {
    title: "Automated Scaling",
    description: "Infrastructure built to handle growth. From 10 to 10,000 clients, our systems scale with you.",
    icon: Zap,
  },
  {
    title: "Secure Payments",
    description: "Enterprise-grade security for all transactions. Your revenue and client data are always protected.",
    icon: Wallet,
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-24 bg-secondary/30">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Everything you need to dominate your market</h2>
          <p className="text-muted-foreground text-lg">
            A complete ecosystem designed for modern founders. We combine powerful software with expert service.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-background p-8 rounded-xl border shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-6">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl mb-3 font-sans font-bold">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
