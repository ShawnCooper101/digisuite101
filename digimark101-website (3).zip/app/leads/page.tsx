import { LeadCaptureSection } from "@/components/lead-capture-section"

export default function LeadsPage() {
  return (
    <main className="min-h-screen pt-16">
      <LeadCaptureSection />
    </main>
  )
}
