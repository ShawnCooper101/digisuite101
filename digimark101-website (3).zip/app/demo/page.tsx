import { DemoLeadCaptureSection } from "@/components/demo-lead-capture-section"

export default function DemoPage() {
  return (
    <main className="min-h-screen pt-16">
      <DemoLeadCaptureSection />
    </main>
  )
}
