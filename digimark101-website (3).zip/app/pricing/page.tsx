import { PricingSection } from "@/components/pricing-section"

export default function PricingPage() {
  return (
    <main className="min-h-screen pt-16">
      <PricingSection />
    </main>
  )
}
