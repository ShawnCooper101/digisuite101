import { SignupForm } from "@/components/signup-form"

export default function SignupPage() {
  return (
    <main className="min-h-screen pt-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Start Your Free Trial</h1>
            <p className="text-gray-600">Join thousands of businesses using AI-powered marketing</p>
          </div>
          <SignupForm />
        </div>
      </div>
    </main>
  )
}
