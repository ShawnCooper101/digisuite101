import { AdminLoginForm } from "@/components/admin-login-form"

export default function AdminLoginPage() {
  return (
    <main className="min-h-screen pt-16 bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center">
      <AdminLoginForm />
    </main>
  )
}
