import { AdminDashboard } from "@/components/admin-dashboard"

export default function AdminPage() {
  return (
    <main className="min-h-screen pt-16 bg-gray-50">
      <AdminDashboard />
    </main>
  )
}
