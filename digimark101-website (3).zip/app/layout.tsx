import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DigiMark101 - AI-Powered Marketing Solutions",
  description:
    "Transform your business with cutting-edge AI marketing automation, data-driven insights, and personalized customer experiences.",
  keywords: "AI marketing, digital marketing, automation, SEO, email marketing, analytics",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  )
}
