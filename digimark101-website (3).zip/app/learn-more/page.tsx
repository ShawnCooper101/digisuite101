import { LearnMoreSection } from "@/components/learn-more-section"

export default function LearnMorePage() {
  return (
    <main className="min-h-screen pt-16">
      <LearnMoreSection />
    </main>
  )
}
