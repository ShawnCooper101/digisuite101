import { BusinessLoansSection } from "@/components/business-loans-section"

export default function BusinessLoansPage() {
  return (
    <main className="min-h-screen pt-16">
      <BusinessLoansSection />
    </main>
  )
}
