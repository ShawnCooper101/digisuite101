"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 w-full bg-black/95 backdrop-blur-sm border-b border-cyan-500/20 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="relative">
              {/* Outer frame */}
              <div className="w-12 h-12 border-2 border-cyan-400 rounded-lg bg-gradient-to-br from-gray-900 to-black flex items-center justify-center relative overflow-hidden">
                {/* Inner geometric elements */}
                <div className="absolute top-1 right-1 w-2 h-2 border border-cyan-400 rounded-sm"></div>
                <div className="absolute bottom-1 left-1 w-3 h-0.5 bg-cyan-400"></div>
                <div className="absolute bottom-1 left-1 w-0.5 h-3 bg-cyan-400"></div>

                {/* Main text */}
                <div className="text-center">
                  <div className="text-[8px] text-cyan-400 font-bold leading-none">DM</div>
                  <div className="text-white font-bold text-sm leading-none">101</div>
                </div>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg text-white">DigiMark101</span>
              <span className="text-xs text-cyan-400 -mt-1">AI MARKETING</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-300 hover:text-cyan-400 transition-colors">
              Home
            </Link>
            <Link href="/demo" className="text-gray-300 hover:text-cyan-400 transition-colors">
              Demo
            </Link>
            <Link href="/services" className="text-gray-300 hover:text-cyan-400 transition-colors">
              Services
            </Link>
            <Link href="/pricing" className="text-gray-300 hover:text-cyan-400 transition-colors">
              Pricing
            </Link>
            <Link href="/learn-more" className="text-gray-300 hover:text-cyan-400 transition-colors">
              Learn More
            </Link>
            <Link href="/contact" className="text-gray-300 hover:text-cyan-400 transition-colors">
              Contact
            </Link>
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/login">
              <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-gray-800">
                Login
              </Button>
            </Link>
            <Link href="/leads">
              <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border border-cyan-400/50 shadow-lg shadow-cyan-500/25">
                Get Started
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-800">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-300 hover:text-cyan-400 transition-colors">
                Home
              </Link>
              <Link href="/demo" className="text-gray-300 hover:text-cyan-400 transition-colors">
                Demo
              </Link>
              <Link href="/services" className="text-gray-300 hover:text-cyan-400 transition-colors">
                Services
              </Link>
              <Link href="/pricing" className="text-gray-300 hover:text-cyan-400 transition-colors">
                Pricing
              </Link>
              <Link href="/learn-more" className="text-gray-300 hover:text-cyan-400 transition-colors">
                Learn More
              </Link>
              <Link href="/contact" className="text-gray-300 hover:text-cyan-400 transition-colors">
                Contact
              </Link>
              <div className="flex flex-col space-y-2 pt-4">
                <Link href="/login">
                  <Button variant="ghost" className="w-full text-gray-300 hover:text-white hover:bg-gray-800">
                    Login
                  </Button>
                </Link>
                <Link href="/leads">
                  <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border border-cyan-400/50">
                    Get Started
                  </Button>
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
