"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Edit, Trash2, Plus, X, LogOut, Shield, Save } from "lucide-react"

interface Service {
  id: string
  name: string
  description: string
  price: number
  category: "basic" | "professional" | "enterprise" | "diy" | "dfy" | "loan"
  features: string[]
  active: boolean
  popular: boolean
}

export function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [adminEmail, setAdminEmail] = useState("")
  const router = useRouter()

  const [services, setServices] = useState<Service[]>([
    {
      id: "1",
      name: "Starter Plan",
      description: "Perfect for small businesses getting started",
      price: 97,
      category: "basic",
      features: ["Up to 2,500 contacts", "Email marketing", "Basic analytics"],
      active: true,
      popular: false,
    },
    {
      id: "2",
      name: "Professional Plan",
      description: "Advanced features for growing businesses",
      price: 297,
      category: "professional",
      features: ["Up to 25,000 contacts", "Advanced automation", "Webinar hosting"],
      active: true,
      popular: true,
    },
    {
      id: "3",
      name: "Business Line of Credit",
      description: "Flexible access to funds when you need them",
      price: 10000,
      category: "loan",
      features: ["$10K - $500K available", "8.99% APR", "Revolving credit"],
      active: true,
      popular: false,
    },
  ])

  const [editingService, setEditingService] = useState<Service | null>(null)
  const [newService, setNewService] = useState<Partial<Service>>({
    name: "",
    description: "",
    price: 0,
    category: "basic",
    features: [],
    active: true,
    popular: false,
  })

  useEffect(() => {
    const authenticated = localStorage.getItem("admin_authenticated")
    const email = localStorage.getItem("admin_email")

    if (authenticated === "true" && email) {
      setIsAuthenticated(true)
      setAdminEmail(email)
    } else {
      router.push("/admin/login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("admin_authenticated")
    localStorage.removeItem("admin_email")
    router.push("/admin/login")
  }

  const handleUpdateService = (updatedService: Service) => {
    setServices((prev) => prev.map((service) => (service.id === updatedService.id ? updatedService : service)))
    setEditingService(null)
  }

  const handleAddService = () => {
    if (newService.name && newService.description && newService.price) {
      const service: Service = {
        id: Date.now().toString(),
        name: newService.name,
        description: newService.description,
        price: newService.price,
        category: newService.category || "basic",
        features: newService.features || [],
        active: newService.active !== false,
        popular: newService.popular || false,
      }
      setServices((prev) => [...prev, service])
      setNewService({
        name: "",
        description: "",
        price: 0,
        category: "basic",
        features: [],
        active: true,
        popular: false,
      })
    }
  }

  const handleDeleteService = (serviceId: string) => {
    setServices((prev) => prev.filter((service) => service.id !== serviceId))
  }

  const addFeatureToService = (service: Service | Partial<Service>, feature: string) => {
    if (feature.trim()) {
      const updatedFeatures = [...(service.features || []), feature.trim()]
      if ("id" in service) {
        setEditingService({ ...service, features: updatedFeatures })
      } else {
        setNewService({ ...service, features: updatedFeatures })
      }
    }
  }

  const removeFeatureFromService = (service: Service | Partial<Service>, index: number) => {
    const updatedFeatures = (service.features || []).filter((_, i) => i !== index)
    if ("id" in service) {
      setEditingService({ ...service, features: updatedFeatures })
    } else {
      setNewService({ ...service, features: updatedFeatures })
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center">
        <div className="text-white text-center">
          <Shield className="w-16 h-16 mx-auto mb-4 text-cyan-400" />
          <h2 className="text-2xl font-bold mb-2">Authenticating...</h2>
          <p className="text-gray-400">Please wait while we verify your credentials.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">DigiMark101 Admin Dashboard</h1>
            <p className="text-gray-400">Welcome back, {adminEmail}</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-red-500/50 text-red-400 hover:bg-red-500/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Backend Integration Info */}
        <div className="mb-8 p-4 bg-blue-900/20 border border-blue-500/30 rounded-lg">
          <p className="text-blue-300 text-sm">
            <strong>Backend Integration:</strong> All data syncs with app.allinonemarketing.com platform
          </p>
        </div>

        <Tabs defaultValue="services" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800 border border-gray-700">
            <TabsTrigger value="services" className="text-gray-300 data-[state=active]:text-white">
              Services & Plans
            </TabsTrigger>
            <TabsTrigger value="loans" className="text-gray-300 data-[state=active]:text-white">
              Business Loans
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-gray-300 data-[state=active]:text-white">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="settings" className="text-gray-300 data-[state=active]:text-white">
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="services" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold text-white">Services & Plans Management</h2>
            </div>

            {/* Add New Service */}
            <Card className="bg-gray-900/50 border border-cyan-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Add New Service/Plan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Service Name</Label>
                    <Input
                      value={newService.name || ""}
                      onChange={(e) => setNewService({ ...newService, name: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="e.g., Professional Plan"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Price ($)</Label>
                    <Input
                      type="number"
                      value={newService.price || 0}
                      onChange={(e) => setNewService({ ...newService, price: Number.parseInt(e.target.value) })}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Category</Label>
                  <Select
                    onValueChange={(value: "basic" | "professional" | "enterprise" | "diy" | "dfy" | "loan") =>
                      setNewService({ ...newService, category: value })
                    }
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic Plan</SelectItem>
                      <SelectItem value="professional">Professional Plan</SelectItem>
                      <SelectItem value="enterprise">Enterprise Plan</SelectItem>
                      <SelectItem value="diy">DIY Service</SelectItem>
                      <SelectItem value="dfy">DFY Service</SelectItem>
                      <SelectItem value="loan">Business Loan</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-gray-300">Description</Label>
                  <Textarea
                    value={newService.description || ""}
                    onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Describe the service..."
                  />
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={newService.popular || false}
                      onCheckedChange={(checked) => setNewService({ ...newService, popular: checked })}
                    />
                    <Label className="text-gray-300">Popular</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={newService.active !== false}
                      onCheckedChange={(checked) => setNewService({ ...newService, active: checked })}
                    />
                    <Label className="text-gray-300">Active</Label>
                  </div>
                </div>

                <Button onClick={handleAddService} className="bg-cyan-600 hover:bg-cyan-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Service
                </Button>
              </CardContent>
            </Card>

            {/* Services List */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service) => (
                <Card key={service.id} className="bg-gray-900/50 border border-gray-700/50 backdrop-blur-sm">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white text-lg">{service.name}</CardTitle>
                        <div className="flex gap-2 mt-2">
                          <Badge
                            variant={
                              service.category === "basic"
                                ? "default"
                                : service.category === "professional"
                                  ? "secondary"
                                  : service.category === "enterprise"
                                    ? "outline"
                                    : service.category === "loan"
                                      ? "destructive"
                                      : "default"
                            }
                          >
                            {service.category.toUpperCase()}
                          </Badge>
                          {service.popular && <Badge className="bg-yellow-500">Popular</Badge>}
                          <Badge variant={service.active ? "default" : "secondary"}>
                            {service.active ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => setEditingService(service)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleDeleteService(service.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <p className="text-gray-400 text-sm">{service.description}</p>
                      <div className="text-2xl font-bold text-cyan-400">
                        ${service.category === "loan" ? service.price.toLocaleString() : service.price}
                        {service.category !== "loan" && <span className="text-sm text-gray-400">/month</span>}
                      </div>
                      <div>
                        <h4 className="font-medium text-white text-sm mb-2">Features:</h4>
                        <ul className="text-xs text-gray-400 space-y-1">
                          {service.features.map((feature, index) => (
                            <li key={index}>• {feature}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Edit Service Modal */}
            {editingService && (
              <Card className="border-2 border-cyan-500 bg-gray-900/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-white">
                    Edit Service: {editingService.name}
                    <Button size="sm" variant="outline" onClick={() => setEditingService(null)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Service Name</Label>
                      <Input
                        value={editingService.name}
                        onChange={(e) => setEditingService({ ...editingService, name: e.target.value })}
                        className="bg-gray-800 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Price ($)</Label>
                      <Input
                        type="number"
                        value={editingService.price}
                        onChange={(e) =>
                          setEditingService({ ...editingService, price: Number.parseInt(e.target.value) })
                        }
                        className="bg-gray-800 border-gray-600 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300">Description</Label>
                    <Textarea
                      value={editingService.description}
                      onChange={(e) => setEditingService({ ...editingService, description: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>

                  <div>
                    <Label className="text-gray-300">Features</Label>
                    <div className="space-y-2">
                      {editingService.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Input value={feature} readOnly className="flex-1 bg-gray-800 border-gray-600 text-white" />
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => removeFeatureFromService(editingService, index)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                      <div className="flex space-x-2">
                        <Input
                          placeholder="Add new feature"
                          className="bg-gray-800 border-gray-600 text-white"
                          onKeyPress={(e) => {
                            if (e.key === "Enter") {
                              addFeatureToService(editingService, e.currentTarget.value)
                              e.currentTarget.value = ""
                            }
                          }}
                        />
                        <Button
                          size="sm"
                          onClick={(e) => {
                            const input = e.currentTarget.previousElementSibling as HTMLInputElement
                            addFeatureToService(editingService, input.value)
                            input.value = ""
                          }}
                        >
                          Add
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={editingService.popular}
                        onCheckedChange={(checked) => setEditingService({ ...editingService, popular: checked })}
                      />
                      <Label className="text-gray-300">Popular</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={editingService.active}
                        onCheckedChange={(checked) => setEditingService({ ...editingService, active: checked })}
                      />
                      <Label className="text-gray-300">Active</Label>
                    </div>
                  </div>

                  <Button onClick={() => handleUpdateService(editingService)} className="bg-cyan-600 hover:bg-cyan-700">
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="loans" className="space-y-6">
            <Card className="bg-gray-900/50 border border-green-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Business Loan Options</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  {services
                    .filter((service) => service.category === "loan")
                    .map((loan) => (
                      <div key={loan.id} className="bg-gray-800/50 border border-green-500/30 rounded-lg p-4">
                        <h3 className="text-lg font-semibold text-white mb-2">{loan.name}</h3>
                        <p className="text-gray-400 text-sm mb-3">{loan.description}</p>
                        <div className="text-2xl font-bold text-green-400 mb-3">${loan.price.toLocaleString()}</div>
                        <ul className="space-y-1">
                          {loan.features.map((feature, index) => (
                            <li key={index} className="text-gray-300 text-sm">
                              • {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card className="bg-gray-900/50 border border-cyan-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Analytics Dashboard</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-cyan-400">3,247</div>
                    <div className="text-sm text-gray-400">Total Signups</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400">$187,450</div>
                    <div className="text-sm text-gray-400">Monthly Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-400">18.7%</div>
                    <div className="text-sm text-gray-400">Conversion Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-400">1,834</div>
                    <div className="text-sm text-gray-400">Active Subscribers</div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-white mb-4">Popular Services</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Professional Plan</span>
                        <Badge>847 subscribers</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Starter Plan</span>
                        <Badge>623 subscribers</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">Enterprise Plan</span>
                        <Badge>364 subscribers</Badge>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-white mb-4">Recent Activity</h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-300">New signup: Professional Plan</span>
                        <span className="text-gray-500">5 min ago</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Service updated: Starter Plan</span>
                        <span className="text-gray-500">2 hours ago</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">New loan application</span>
                        <span className="text-gray-500">4 hours ago</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-gray-900/50 border border-cyan-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">System Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="text-gray-300">Backend API URL</Label>
                  <Input
                    value="app.allinonemarketing.com"
                    readOnly
                    className="bg-gray-800 border-gray-600 text-gray-400"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    All form submissions and user data sync with this backend
                  </p>
                </div>

                <div>
                  <Label className="text-gray-300">Admin Email</Label>
                  <Input value={adminEmail} readOnly className="bg-gray-800 border-gray-600 text-gray-400" />
                </div>

                <div>
                  <Label className="text-gray-300">Company Name</Label>
                  <Input defaultValue="DigiMark101" className="bg-gray-800 border-gray-600 text-white" />
                </div>

                <div>
                  <Label className="text-gray-300">Support Email</Label>
                  <Input defaultValue="support@digimark101.com" className="bg-gray-800 border-gray-600 text-white" />
                </div>

                <Button className="bg-cyan-600 hover:bg-cyan-700">Save Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
