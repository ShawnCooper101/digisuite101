"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Check, ArrowRight, Users, Wrench, BarChart3, Mail, Search, Globe, MessageSquare } from "lucide-react"
import Link from "next/link"

const diyServices = [
  {
    icon: Search,
    title: "DIY SEO Toolkit",
    description: "Complete SEO tools and training to optimize your website yourself",
    features: [
      "SEO audit tools",
      "Keyword research platform",
      "Content optimization guides",
      "Technical SEO checklist",
      "Monthly training webinars",
      "Community support forum",
    ],
    price: 97,
    popular: false,
  },
  {
    icon: Mail,
    title: "DIY Email Marketing",
    description: "Email marketing platform with templates and automation tools",
    features: [
      "Drag & drop email builder",
      "Pre-built automation sequences",
      "A/B testing tools",
      "Analytics dashboard",
      "Template library (500+)",
      "Integration tutorials",
    ],
    price: 67,
    popular: true,
  },
  {
    icon: MessageSquare,
    title: "DIY Social Media",
    description: "Social media management tools and content creation resources",
    features: [
      "Content calendar planner",
      "Post scheduling tools",
      "Hashtag research",
      "Engagement tracking",
      "Content templates",
      "Strategy guides",
    ],
    price: 47,
    popular: false,
  },
  {
    icon: BarChart3,
    title: "DIY Analytics Suite",
    description: "Comprehensive analytics and reporting tools for all your marketing",
    features: [
      "Multi-platform tracking",
      "Custom dashboard builder",
      "ROI calculators",
      "Conversion tracking",
      "Report templates",
      "Data visualization tools",
    ],
    price: 77,
    popular: false,
  },
]

const dfyServices = [
  {
    icon: Search,
    title: "DFY SEO Management",
    description: "Complete SEO management handled by our expert team",
    features: [
      "Monthly SEO audits",
      "Keyword research & strategy",
      "Content creation & optimization",
      "Technical SEO fixes",
      "Link building campaigns",
      "Monthly performance reports",
      "Dedicated SEO specialist",
    ],
    price: 1497,
    popular: false,
  },
  {
    icon: Mail,
    title: "DFY Email Marketing",
    description: "Full email marketing management and campaign creation",
    features: [
      "Email strategy development",
      "Campaign design & copywriting",
      "List segmentation & management",
      "Automation setup",
      "A/B testing & optimization",
      "Performance monitoring",
      "Monthly strategy calls",
    ],
    price: 997,
    popular: true,
  },
  {
    icon: MessageSquare,
    title: "DFY Social Media",
    description: "Complete social media management across all platforms",
    features: [
      "Content creation & posting",
      "Community management",
      "Paid advertising management",
      "Influencer outreach",
      "Brand monitoring",
      "Monthly analytics reports",
      "Dedicated social media manager",
    ],
    price: 1997,
    popular: false,
  },
  {
    icon: Globe,
    title: "DFY Digital Marketing",
    description: "Complete digital marketing solution with dedicated team",
    features: [
      "Full marketing strategy",
      "Multi-channel campaigns",
      "Creative design & copywriting",
      "Landing page optimization",
      "Conversion rate optimization",
      "Weekly strategy meetings",
      "Dedicated marketing team",
    ],
    price: 2997,
    popular: false,
  },
]

const packages = [
  {
    name: "Starter Package",
    description: "Perfect for small businesses just getting started",
    price: 297,
    originalPrice: 450,
    includes: ["DIY SEO Toolkit", "DIY Email Marketing", "Basic Support"],
    savings: "Save $153/month",
  },
  {
    name: "Growth Package",
    description: "Ideal for businesses ready to scale their marketing",
    price: 497,
    originalPrice: 750,
    includes: ["All DIY Tools", "DFY Email Marketing", "Priority Support", "Monthly Strategy Call"],
    savings: "Save $253/month",
    popular: true,
  },
  {
    name: "Pro Package",
    description: "Complete marketing solution for serious growth",
    price: 1497,
    originalPrice: 2200,
    includes: ["All DIY Tools", "DFY SEO Management", "DFY Email Marketing", "Dedicated Account Manager"],
    savings: "Save $703/month",
  },
  {
    name: "Enterprise Package",
    description: "Full-service marketing for established businesses",
    price: 2997,
    originalPrice: 4500,
    includes: ["Everything Included", "DFY Digital Marketing", "Weekly Strategy Meetings", "Priority Support"],
    savings: "Save $1,503/month",
  },
]

export function LearnMoreSection() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">Choose Your Marketing Path</h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-8">
            Whether you prefer to Do It Yourself (DIY) with our powerful tools and training, or have us Do It For You
            (DFY) with our expert team, we have the perfect solution for your business.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="diy">DIY Tools</TabsTrigger>
            <TabsTrigger value="dfy">DFY Services</TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-12">
            {/* Comparison Section */}
            <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
              <Card className="relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-500 to-emerald-400"></div>
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Wrench className="w-8 h-8 text-green-600" />
                  </div>
                  <CardTitle className="text-2xl">DIY (Do It Yourself)</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 text-center">
                    Get access to professional-grade tools, training, and resources to manage your marketing in-house.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-green-500" />
                      <span>Professional marketing tools</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-green-500" />
                      <span>Step-by-step training</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-green-500" />
                      <span>Community support</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-green-500" />
                      <span>Cost-effective solution</span>
                    </li>
                  </ul>
                  <div className="text-center pt-4">
                    <div className="text-2xl font-bold text-green-600 mb-2">Starting at $47/month</div>
                    <Button className="bg-green-600 hover:bg-green-700" onClick={() => setActiveTab("diy")}>
                      Explore DIY Tools
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-500 to-cyan-400"></div>
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-8 h-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-2xl">DFY (Done For You)</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 text-center">
                    Let our expert team handle your marketing while you focus on running your business.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-blue-500" />
                      <span>Expert team management</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-blue-500" />
                      <span>Hands-off approach</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-blue-500" />
                      <span>Proven strategies</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-blue-500" />
                      <span>Guaranteed results</span>
                    </li>
                  </ul>
                  <div className="text-center pt-4">
                    <div className="text-2xl font-bold text-blue-600 mb-2">Starting at $997/month</div>
                    <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setActiveTab("dfy")}>
                      Explore DFY Services
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="diy" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">DIY Marketing Tools</h2>
              <p className="text-lg text-gray-600">Professional-grade tools with training and support</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {diyServices.map((service, index) => (
                <Card key={index} className={`relative ${service.popular ? "ring-2 ring-green-500" : ""}`}>
                  {service.popular && (
                    <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-green-500">
                      Most Popular
                    </Badge>
                  )}
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <service.icon className="w-6 h-6 text-green-600" />
                    </div>
                    <CardTitle className="text-lg">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-600 text-sm">{service.description}</p>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start space-x-2 text-sm">
                          <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="border-t pt-4">
                      <div className="text-2xl font-bold text-green-600 mb-3">${service.price}/month</div>
                      <Link href="/signup">
                        <Button className="w-full bg-green-600 hover:bg-green-700">Get Started</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="dfy" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Done For You Services</h2>
              <p className="text-lg text-gray-600">Expert team management with guaranteed results</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {dfyServices.map((service, index) => (
                <Card key={index} className={`relative ${service.popular ? "ring-2 ring-blue-500" : ""}`}>
                  {service.popular && (
                    <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-blue-500">
                      Most Popular
                    </Badge>
                  )}
                  <CardHeader>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <service.icon className="w-6 h-6 text-blue-600" />
                      </div>
                      <CardTitle className="text-xl">{service.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-600">{service.description}</p>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start space-x-2">
                          <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700 text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="border-t pt-4">
                      <div className="text-3xl font-bold text-blue-600 mb-3">${service.price}/month</div>
                      <Link href="/contact">
                        <Button className="w-full bg-blue-600 hover:bg-blue-700">Schedule Consultation</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="packages" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Complete Marketing Packages</h2>
              <p className="text-lg text-gray-600">Bundled solutions that combine DIY tools with DFY services</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {packages.map((pkg, index) => (
                <Card key={index} className={`relative ${pkg.popular ? "ring-2 ring-purple-500 scale-105" : ""}`}>
                  {pkg.popular && (
                    <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-purple-500">
                      Best Value
                    </Badge>
                  )}
                  <CardHeader className="text-center">
                    <CardTitle className="text-xl">{pkg.name}</CardTitle>
                    <p className="text-gray-600 text-sm">{pkg.description}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-600">${pkg.price}</div>
                      <div className="text-sm text-gray-500 line-through">${pkg.originalPrice}/month</div>
                      <div className="text-sm text-green-600 font-medium">{pkg.savings}</div>
                    </div>

                    <ul className="space-y-2">
                      {pkg.includes.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start space-x-2 text-sm">
                          <Check className="w-4 h-4 text-purple-500 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{item}</span>
                        </li>
                      ))}
                    </ul>

                    <Link href="/signup">
                      <Button
                        className={`w-full ${pkg.popular ? "bg-purple-600 hover:bg-purple-700" : "bg-gray-900 hover:bg-gray-800"}`}
                      >
                        Get Started
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* CTA Section */}
        <div className="text-center mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-white">
          <h3 className="text-3xl font-bold mb-4">Not Sure Which Option Is Right for You?</h3>
          <p className="text-xl mb-8 opacity-90">
            Schedule a free consultation with our marketing experts to find the perfect solution for your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                Schedule Free Consultation
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600"
              >
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
