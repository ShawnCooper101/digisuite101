import { Bot, BarChart3, Mail, Search, Users, Zap } from "lucide-react"

const features = [
  {
    icon: Bot,
    title: "AI-Powered Automation",
    description: "Intelligent marketing automation that learns and adapts to your audience behavior in real-time.",
  },
  {
    icon: BarChart3,
    title: "Advanced Analytics",
    description: "Deep insights and predictive analytics to optimize your marketing campaigns and ROI.",
  },
  {
    icon: Mail,
    title: "Email Marketing",
    description: "Personalized email campaigns with AI-driven content optimization and timing.",
  },
  {
    icon: Search,
    title: "SEO Optimization",
    description: "AI-enhanced SEO strategies that boost your search rankings and organic traffic.",
  },
  {
    icon: Users,
    title: "Customer Segmentation",
    description: "Smart audience segmentation for targeted campaigns and personalized experiences.",
  },
  {
    icon: Zap,
    title: "Real-time Optimization",
    description: "Continuous campaign optimization based on live performance data and AI insights.",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Powerful AI Marketing Features</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Leverage cutting-edge artificial intelligence to transform your marketing strategy and drive unprecedented
            growth.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group p-8 rounded-2xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
