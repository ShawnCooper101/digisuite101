import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import Link from "next/link"

const services = [
  {
    title: "SEO & Content Marketing",
    description: "AI-driven SEO strategies and content creation",
    features: ["Keyword Research & Analysis", "Content Optimization", "Technical SEO Audit", "Competitor Analysis"],
    price: "Starting at $299/mo",
  },
  {
    title: "Email Marketing Automation",
    description: "Personalized email campaigns with AI optimization",
    features: ["Automated Drip Campaigns", "A/B Testing", "Behavioral Triggers", "Performance Analytics"],
    price: "Starting at $199/mo",
  },
  {
    title: "Social Media Management",
    description: "AI-powered social media strategy and execution",
    features: ["Content Creation", "Posting Automation", "Engagement Tracking", "Audience Growth"],
    price: "Starting at $399/mo",
  },
]

export function ServicesSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Marketing Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive AI-powered marketing solutions tailored to your business needs.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <h3 className="text-2xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600 mb-6">{service.description}</p>

              <ul className="space-y-3 mb-8">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="border-t pt-6">
                <div className="text-2xl font-bold text-blue-600 mb-4">{service.price}</div>
                <Link href="/contact">
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600">
                    Get Started
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
