"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, ArrowRight, Sparkles, DollarSign, TrendingUp, Shield } from "lucide-react"
import Link from "next/link"

const loanOptions = [
  {
    name: "Business Line of Credit",
    amount: "$10K - $500K",
    rate: "Starting at 8.99% APR",
    term: "Revolving Credit",
    description: "Flexible access to funds when you need them most",
    features: [
      "Draw funds as needed",
      "Only pay interest on what you use",
      "No collateral required up to $100K",
      "Quick approval process",
      "Perfect for cash flow management",
    ],
    popular: false,
    color: "blue",
  },
  {
    name: "SBA Loans",
    amount: "$50K - $5M",
    rate: "Starting at 6.5% APR",
    term: "5-25 years",
    description: "Government-backed loans with competitive rates",
    features: [
      "Lower down payments",
      "Competitive interest rates",
      "Longer repayment terms",
      "Various SBA programs available",
      "Expert guidance through process",
    ],
    popular: true,
    color: "green",
  },
  {
    name: "Equipment Financing",
    amount: "$25K - $2M",
    rate: "Starting at 7.99% APR",
    term: "2-7 years",
    description: "Finance equipment purchases with the equipment as collateral",
    features: [
      "100% financing available",
      "Equipment serves as collateral",
      "Preserve working capital",
      "Tax advantages available",
      "Fast approval and funding",
    ],
    popular: false,
    color: "purple",
  },
  {
    name: "Revenue-Based Financing",
    amount: "$10K - $1M",
    rate: "Factor Rate 1.1-1.5",
    term: "3-18 months",
    description: "Funding based on your business revenue",
    features: [
      "No fixed monthly payments",
      "Payments based on revenue",
      "Quick funding (24-48 hours)",
      "No collateral required",
      "Perfect for seasonal businesses",
    ],
    popular: false,
    color: "cyan",
  },
]

const benefits = [
  {
    icon: DollarSign,
    title: "Competitive Rates",
    description: "Access to the best rates in the market through our lending network",
  },
  {
    icon: TrendingUp,
    title: "Fast Approval",
    description: "Get approved in as little as 24 hours with our streamlined process",
  },
  {
    icon: Shield,
    title: "Expert Guidance",
    description: "Our loan specialists guide you through every step of the process",
  },
]

export function BusinessLoansSection() {
  const [selectedLoan, setSelectedLoan] = useState<string | null>(null)

  return (
    <section className="py-20 bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Sparkles className="w-6 h-6 text-green-400" />
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-1">
              Business Funding
            </Badge>
          </div>

          <h1 className="text-5xl font-bold text-white mb-6">
            Fuel Your Business{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">Growth</span>
          </h1>

          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Access the capital you need to scale your business with our comprehensive lending solutions. From working
            capital to equipment financing, we have the right funding option for your needs.
          </p>
        </div>

        {/* Benefits Section */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <Card key={index} className="bg-gray-900/50 border border-green-500/20 backdrop-blur-sm text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="w-6 h-6 text-green-400" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{benefit.title}</h3>
                <p className="text-gray-400">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Loan Options */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {loanOptions.map((loan, index) => (
            <Card
              key={index}
              className={`relative bg-gray-900/50 border backdrop-blur-sm hover:shadow-2xl transition-all duration-300 cursor-pointer ${
                loan.popular
                  ? "ring-2 ring-green-500 scale-105 border-green-500/50"
                  : `border-${loan.color}-500/30 hover:border-${loan.color}-500/50`
              } ${selectedLoan === loan.name ? "ring-2 ring-cyan-400" : ""}`}
              onClick={() => setSelectedLoan(selectedLoan === loan.name ? null : loan.name)}
            >
              {loan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-1">
                    Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <CardTitle className="text-xl text-white">{loan.name}</CardTitle>
                  <Badge variant="outline" className={`border-${loan.color}-500 text-${loan.color}-400`}>
                    {loan.amount}
                  </Badge>
                </div>
                <p className="text-gray-400">{loan.description}</p>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Rate:</span>
                    <div className="text-white font-semibold">{loan.rate}</div>
                  </div>
                  <div>
                    <span className="text-gray-400">Term:</span>
                    <div className="text-white font-semibold">{loan.term}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold text-white text-sm">Key Features:</h4>
                  <ul className="space-y-1">
                    {loan.features
                      .slice(0, selectedLoan === loan.name ? loan.features.length : 3)
                      .map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start space-x-2 text-sm">
                          <Check className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-300">{feature}</span>
                        </li>
                      ))}
                  </ul>
                  {loan.features.length > 3 && selectedLoan !== loan.name && (
                    <button className="text-cyan-400 text-sm hover:text-cyan-300">
                      +{loan.features.length - 3} more features
                    </button>
                  )}
                </div>

                <Link href="/contact">
                  <Button
                    className={`w-full mt-4 ${
                      loan.popular
                        ? "bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                        : loan.color === "blue"
                          ? "bg-blue-600 hover:bg-blue-700"
                          : loan.color === "purple"
                            ? "bg-purple-600 hover:bg-purple-700"
                            : "bg-cyan-600 hover:bg-cyan-700"
                    }`}
                  >
                    Apply Now
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Application Process */}
        <Card className="bg-gray-900/50 border border-green-500/20 backdrop-blur-sm mb-16">
          <CardHeader>
            <CardTitle className="text-2xl text-white text-center">Simple Application Process</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-8">
              {[
                { step: "1", title: "Apply Online", desc: "Complete our simple application in minutes" },
                { step: "2", title: "Get Matched", desc: "We match you with the best lenders" },
                { step: "3", title: "Review Offers", desc: "Compare rates and terms from multiple lenders" },
                { step: "4", title: "Get Funded", desc: "Receive funds as fast as 24 hours" },
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold">
                    {item.step}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-gray-900/50 to-gray-800/50 border border-green-500/20 rounded-2xl p-12 backdrop-blur-sm">
          <h3 className="text-3xl font-bold text-white mb-4">Ready to Secure Your Business Funding?</h3>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Get pre-qualified in minutes and access up to $5M in business funding with competitive rates and flexible
            terms.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 px-8 py-4"
              >
                Start Application
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                size="lg"
                variant="outline"
                className="border-green-400/50 text-green-400 hover:bg-green-400/10 px-8 py-4"
              >
                Speak with Specialist
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
