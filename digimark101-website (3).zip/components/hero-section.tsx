import { Button } from "@/components/ui/button"
import { ArrowRight, Bot, TrendingUp, Zap, Sparkles, Play } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-black via-gray-900 to-black pt-16 overflow-hidden">
      {/* Animated background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.03)_1px,transparent_1px)] bg-[size:50px_50px] animate-pulse"></div>

      {/* Floating orbs */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
                <span className="text-cyan-400 text-sm font-medium tracking-wider uppercase">AI-Powered Marketing</span>
              </div>

              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                <span className="text-white">DigiMark</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">101</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 text-3xl lg:text-4xl mt-2">
                  AI-DRIVEN MARKETING
                </span>
                <span className="block text-gray-300 text-2xl lg:text-3xl font-light">SOLUTIONS</span>
              </h1>

              <p className="text-xl text-gray-300 max-w-lg leading-relaxed">
                Transform your business with cutting-edge AI marketing automation, data-driven insights, and
                personalized customer experiences that deliver
                <span className="text-cyan-400 font-semibold"> guaranteed results</span>.
              </p>
            </div>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center space-x-2 bg-gray-900/50 border border-cyan-500/30 rounded-full px-4 py-2 backdrop-blur-sm hover:border-cyan-400 transition-colors">
                <Bot className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-medium text-white">AI Automation</span>
              </div>
              <div className="flex items-center space-x-2 bg-gray-900/50 border border-blue-500/30 rounded-full px-4 py-2 backdrop-blur-sm hover:border-blue-400 transition-colors">
                <TrendingUp className="w-4 h-4 text-blue-400" />
                <span className="text-sm font-medium text-white">Growth Analytics</span>
              </div>
              <div className="flex items-center space-x-2 bg-gray-900/50 border border-purple-500/30 rounded-full px-4 py-2 backdrop-blur-sm hover:border-purple-400 transition-colors">
                <Zap className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-medium text-white">Real-time Optimization</span>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-cyan-400">2,500+</div>
                <div className="text-sm text-gray-400">Clients Served</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">400%</div>
                <div className="text-sm text-gray-400">Avg ROI Increase</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400">24/7</div>
                <div className="text-sm text-gray-400">AI Monitoring</div>
              </div>
            </div>
          </div>

          {/* Right Content - Hero Image with Overlaid Buttons */}
          <div className="relative">
            {/* Main Hero Image Container */}
            <div className="relative bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-6 border border-cyan-500/20 shadow-2xl shadow-cyan-500/10 backdrop-blur-sm">
              {/* Generated AI Marketing Dashboard Image */}
              <div className="relative w-full h-96 bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20 rounded-xl overflow-hidden">
                {/* Simulated Dashboard Interface */}
                <div className="absolute inset-0 p-6 space-y-4">
                  {/* Top Bar */}
                  <div className="flex justify-between items-center">
                    <div className="text-cyan-400 font-bold text-lg">AI Marketing Hub</div>
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                      <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse delay-300"></div>
                      <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse delay-700"></div>
                    </div>
                  </div>

                  {/* Dashboard Cards */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-800/50 border border-cyan-500/30 rounded-lg p-4 backdrop-blur-sm">
                      <div className="text-cyan-400 text-sm mb-2">Campaign Performance</div>
                      <div className="text-white text-2xl font-bold">+347%</div>
                      <div className="w-full h-2 bg-gray-700 rounded-full mt-2">
                        <div className="w-3/4 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"></div>
                      </div>
                    </div>
                    <div className="bg-gray-800/50 border border-blue-500/30 rounded-lg p-4 backdrop-blur-sm">
                      <div className="text-blue-400 text-sm mb-2">Lead Generation</div>
                      <div className="text-white text-2xl font-bold">1,247</div>
                      <div className="text-green-400 text-xs">↗ +23% this week</div>
                    </div>
                  </div>

                  {/* Analytics Chart Simulation */}
                  <div className="bg-gray-800/30 border border-purple-500/30 rounded-lg p-4 backdrop-blur-sm">
                    <div className="text-purple-400 text-sm mb-3">AI Analytics Overview</div>
                    <div className="flex items-end space-x-1 h-16">
                      {[...Array(12)].map((_, i) => (
                        <div
                          key={i}
                          className="bg-gradient-to-t from-cyan-500 to-blue-500 rounded-t flex-1 animate-pulse"
                          style={{
                            height: `${Math.random() * 60 + 20}%`,
                            animationDelay: `${i * 100}ms`,
                          }}
                        ></div>
                      ))}
                    </div>
                  </div>

                  {/* AI Robot Icon */}
                  <div className="absolute bottom-4 right-4 w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
                    <Bot className="w-6 h-6 text-white" />
                  </div>
                </div>

                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/20"></div>
              </div>

              {/* Overlaid Action Buttons */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-black/80 backdrop-blur-md rounded-2xl p-8 border border-cyan-500/30 shadow-2xl">
                  <div className="text-center space-y-6">
                    <h3 className="text-2xl font-bold text-white mb-4">Ready to Transform Your Business?</h3>

                    {/* Primary CTA Buttons */}
                    <div className="flex flex-col space-y-4">
                      <Link href="/signup">
                        <Button
                          size="lg"
                          className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-4 text-lg font-semibold border border-cyan-400/50 shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all duration-300"
                        >
                          Start Free Trial
                          <ArrowRight className="ml-2 w-5 h-5" />
                        </Button>
                      </Link>

                      <div className="grid grid-cols-2 gap-3">
                        <Link href="/learn-more">
                          <Button
                            variant="outline"
                            className="w-full border-cyan-400/50 text-cyan-400 hover:bg-cyan-400/10 hover:border-cyan-400 backdrop-blur-sm"
                          >
                            Learn More
                          </Button>
                        </Link>
                        <Link href="/business-loans">
                          <Button
                            variant="outline"
                            className="w-full border-green-400/50 text-green-400 hover:bg-green-400/10 hover:border-green-400 backdrop-blur-sm"
                          >
                            Business Loans
                          </Button>
                        </Link>
                      </div>

                      <Link href="/demo">
                        <Button variant="ghost" className="w-full text-gray-300 hover:text-white hover:bg-gray-800/50">
                          <Play className="mr-2 w-4 h-4" />
                          Watch Demo
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Decorative Elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-r from-cyan-500/20 to-blue-400/20 rounded-full animate-pulse border border-cyan-400/30"></div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-r from-purple-500/20 to-pink-400/20 rounded-full animate-pulse delay-1000 border border-purple-400/30"></div>

            {/* Geometric Lines */}
            <div className="absolute top-1/4 -left-8 w-16 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"></div>
            <div className="absolute bottom-1/4 -right-8 w-16 h-0.5 bg-gradient-to-r from-transparent via-blue-400 to-transparent"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
