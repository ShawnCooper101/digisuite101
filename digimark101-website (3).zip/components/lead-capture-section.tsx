"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Sparkles, TrendingUp, Zap, ArrowRight, Star } from "lucide-react"

export function LeadCaptureSection() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    company: "",
    phone: "",
    businessType: "",
    monthlyRevenue: "",
    marketingBudget: "",
    primaryGoal: "",
  })

  const [currentStep, setCurrentStep] = useState(1)
  const totalSteps = 3

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission to app.allinonemarketing.com
    console.log("Lead captured:", formData)
    // Show success message or redirect
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const nextStep = () => {
    if (currentStep < totalSteps) setCurrentStep(currentStep + 1)
  }

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1)
  }

  return (
    <section className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black py-20 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.05)_1px,transparent_1px)] bg-[size:50px_50px]"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Sparkles className="w-6 h-6 text-cyan-400" />
              <Badge className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-4 py-1">
                Limited Time Offer
              </Badge>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              Get Your{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">FREE</span>
              <br />
              Marketing Analysis
            </h1>

            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Discover how AI-powered marketing can transform your business. Get a personalized strategy session worth{" "}
              <span className="text-cyan-400 font-bold">$500</span> - completely free.
            </p>

            {/* Benefits */}
            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12">
              <div className="flex items-center space-x-3 bg-gray-900/50 border border-cyan-500/20 rounded-lg p-4 backdrop-blur-sm">
                <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0" />
                <span className="text-white">30-Minute Strategy Call</span>
              </div>
              <div className="flex items-center space-x-3 bg-gray-900/50 border border-blue-500/20 rounded-lg p-4 backdrop-blur-sm">
                <TrendingUp className="w-6 h-6 text-blue-400 flex-shrink-0" />
                <span className="text-white">Custom Growth Plan</span>
              </div>
              <div className="flex items-center space-x-3 bg-gray-900/50 border border-purple-500/20 rounded-lg p-4 backdrop-blur-sm">
                <Zap className="w-6 h-6 text-purple-400 flex-shrink-0" />
                <span className="text-white">ROI Projection Report</span>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Left Side - Social Proof */}
            <div className="space-y-8">
              {/* Testimonial */}
              <Card className="bg-gray-900/50 border border-cyan-500/20 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-300 mb-4 italic">
                    "DigiMark101 transformed our marketing completely. We saw a 400% increase in qualified leads within
                    just 3 months. Their AI-powered approach is game-changing."
                  </p>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-sm">SJ</span>
                    </div>
                    <div>
                      <div className="text-white font-semibold">Sarah Johnson</div>
                      <div className="text-gray-400 text-sm">CEO, TechStart Inc.</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center bg-gray-900/30 border border-cyan-500/20 rounded-lg p-6 backdrop-blur-sm">
                  <div className="text-3xl font-bold text-cyan-400 mb-2">500+</div>
                  <div className="text-gray-300">Businesses Transformed</div>
                </div>
                <div className="text-center bg-gray-900/30 border border-blue-500/20 rounded-lg p-6 backdrop-blur-sm">
                  <div className="text-3xl font-bold text-blue-400 mb-2">$2.5M+</div>
                  <div className="text-gray-300">Revenue Generated</div>
                </div>
              </div>

              {/* Trust Indicators */}
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-gray-300">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span>No long-term contracts required</span>
                </div>
                <div className="flex items-center space-x-3 text-gray-300">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span>100% money-back guarantee</span>
                </div>
                <div className="flex items-center space-x-3 text-gray-300">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span>Setup completed in 24 hours</span>
                </div>
              </div>
            </div>

            {/* Right Side - Lead Form */}
            <Card className="bg-gray-900/50 border border-cyan-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white text-2xl text-center">Claim Your Free Analysis</CardTitle>
                <div className="flex justify-center space-x-2 mt-4">
                  {[...Array(totalSteps)].map((_, i) => (
                    <div
                      key={i}
                      className={`w-8 h-2 rounded-full ${i + 1 <= currentStep ? "bg-cyan-400" : "bg-gray-600"}`}
                    />
                  ))}
                </div>
                <p className="text-center text-gray-400 text-sm">
                  Step {currentStep} of {totalSteps}
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {currentStep === 1 && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white mb-4">Personal Information</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="firstName" className="text-gray-300">
                            First Name
                          </Label>
                          <Input
                            id="firstName"
                            type="text"
                            value={formData.firstName}
                            onChange={(e) => handleInputChange("firstName", e.target.value)}
                            className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="lastName" className="text-gray-300">
                            Last Name
                          </Label>
                          <Input
                            id="lastName"
                            type="text"
                            value={formData.lastName}
                            onChange={(e) => handleInputChange("lastName", e.target.value)}
                            className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                            required
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-gray-300">
                          Email Address
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-gray-300">
                          Phone Number
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handleInputChange("phone", e.target.value)}
                          className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                          required
                        />
                      </div>
                    </div>
                  )}

                  {currentStep === 2 && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white mb-4">Business Information</h3>
                      <div className="space-y-2">
                        <Label htmlFor="company" className="text-gray-300">
                          Company Name
                        </Label>
                        <Input
                          id="company"
                          type="text"
                          value={formData.company}
                          onChange={(e) => handleInputChange("company", e.target.value)}
                          className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="businessType" className="text-gray-300">
                          Business Type
                        </Label>
                        <Select onValueChange={(value) => handleInputChange("businessType", value)}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                            <SelectValue placeholder="Select your business type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ecommerce">E-commerce</SelectItem>
                            <SelectItem value="saas">SaaS</SelectItem>
                            <SelectItem value="consulting">Consulting</SelectItem>
                            <SelectItem value="agency">Agency</SelectItem>
                            <SelectItem value="retail">Retail</SelectItem>
                            <SelectItem value="healthcare">Healthcare</SelectItem>
                            <SelectItem value="finance">Finance</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="monthlyRevenue" className="text-gray-300">
                          Monthly Revenue
                        </Label>
                        <Select onValueChange={(value) => handleInputChange("monthlyRevenue", value)}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                            <SelectValue placeholder="Select revenue range" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="under-10k">Under $10K</SelectItem>
                            <SelectItem value="10k-50k">$10K - $50K</SelectItem>
                            <SelectItem value="50k-100k">$50K - $100K</SelectItem>
                            <SelectItem value="100k-500k">$100K - $500K</SelectItem>
                            <SelectItem value="500k-1m">$500K - $1M</SelectItem>
                            <SelectItem value="over-1m">Over $1M</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  {currentStep === 3 && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white mb-4">Marketing Goals</h3>
                      <div className="space-y-2">
                        <Label htmlFor="marketingBudget" className="text-gray-300">
                          Marketing Budget
                        </Label>
                        <Select onValueChange={(value) => handleInputChange("marketingBudget", value)}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                            <SelectValue placeholder="Select budget range" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="under-1k">Under $1K/month</SelectItem>
                            <SelectItem value="1k-5k">$1K - $5K/month</SelectItem>
                            <SelectItem value="5k-10k">$5K - $10K/month</SelectItem>
                            <SelectItem value="10k-25k">$10K - $25K/month</SelectItem>
                            <SelectItem value="over-25k">Over $25K/month</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="primaryGoal" className="text-gray-300">
                          Primary Goal
                        </Label>
                        <Select onValueChange={(value) => handleInputChange("primaryGoal", value)}>
                          <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                            <SelectValue placeholder="What's your main goal?" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="increase-leads">Increase Leads</SelectItem>
                            <SelectItem value="boost-sales">Boost Sales</SelectItem>
                            <SelectItem value="improve-roi">Improve ROI</SelectItem>
                            <SelectItem value="brand-awareness">Brand Awareness</SelectItem>
                            <SelectItem value="customer-retention">Customer Retention</SelectItem>
                            <SelectItem value="market-expansion">Market Expansion</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between pt-6">
                    {currentStep > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={prevStep}
                        className="border-gray-600 text-gray-300 hover:bg-gray-800"
                      >
                        Previous
                      </Button>
                    )}

                    {currentStep < totalSteps ? (
                      <Button
                        type="button"
                        onClick={nextStep}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white ml-auto"
                      >
                        Next Step
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    ) : (
                      <Button
                        type="submit"
                        className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white ml-auto"
                      >
                        Get My Free Analysis
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
