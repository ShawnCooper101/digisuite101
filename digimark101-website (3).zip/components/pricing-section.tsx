"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, X, ArrowRight, Sparkles } from "lucide-react"
import Link from "next/link"

// Pricing aligned with allinonemarketing.com platform
const pricingPlans = [
  {
    name: "Starter",
    price: { monthly: 97, yearly: 970 },
    description: "Perfect for small businesses getting started",
    features: [
      "Up to 2,500 contacts",
      "Email marketing automation",
      "Basic landing pages",
      "Social media scheduling",
      "Basic analytics",
      "Email support",
      "Mobile app access",
    ],
    notIncluded: ["Advanced funnels", "Webinar hosting", "Priority support", "Custom integrations"],
    popular: false,
    category: "basic",
  },
  {
    name: "Professional",
    price: { monthly: 297, yearly: 2970 },
    description: "Advanced features for growing businesses",
    features: [
      "Up to 25,000 contacts",
      "Advanced email automation",
      "Sales funnel builder",
      "Webinar hosting (up to 100)",
      "A/B testing",
      "Advanced analytics",
      "Priority email support",
      "Custom domains",
      "Membership sites",
    ],
    notIncluded: ["Unlimited webinars", "White-label", "Phone support"],
    popular: true,
    category: "professional",
  },
  {
    name: "Enterprise",
    price: { monthly: 497, yearly: 4970 },
    description: "Complete solution for large businesses",
    features: [
      "Unlimited contacts",
      "Advanced automation workflows",
      "Unlimited webinars",
      "Advanced funnel builder",
      "White-label options",
      "Priority phone support",
      "Custom integrations",
      "Dedicated account manager",
      "Advanced reporting",
      "API access",
    ],
    notIncluded: [],
    popular: false,
    category: "enterprise",
  },
]

// DIY and DFY Add-ons
const addOnServices = [
  {
    name: "DIY Marketing Toolkit",
    price: 67,
    description: "Self-service marketing tools and training",
    features: ["Marketing templates", "Training videos", "Strategy guides", "Community access"],
    category: "diy",
  },
  {
    name: "DFY Setup Service",
    price: 497,
    description: "We set up everything for you",
    features: ["Complete account setup", "Campaign creation", "Integration setup", "Training session"],
    category: "dfy",
  },
  {
    name: "DFY Management",
    price: 997,
    description: "Full marketing management service",
    features: ["Campaign management", "Content creation", "Performance optimization", "Monthly reports"],
    category: "dfy",
  },
]

export function PricingSection() {
  const [isYearly, setIsYearly] = useState(false)
  const [showAddOns, setShowAddOns] = useState(false)

  return (
    <section className="py-20 bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Sparkles className="w-6 h-6 text-cyan-400" />
            <Badge className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-4 py-1">
              All-in-One Platform
            </Badge>
          </div>

          <h1 className="text-5xl font-bold text-white mb-6">
            Choose Your{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
              Marketing Plan
            </span>
          </h1>

          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            All plans include our complete marketing automation platform. Add DIY tools or DFY services to customize
            your experience.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-12">
            <span className={`text-sm ${!isYearly ? "text-white font-medium" : "text-gray-400"}`}>Monthly</span>
            <button
              onClick={() => setIsYearly(!isYearly)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                isYearly ? "bg-cyan-500" : "bg-gray-600"
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isYearly ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
            <span className={`text-sm ${isYearly ? "text-white font-medium" : "text-gray-400"}`}>Yearly</span>
            {isYearly && <Badge className="bg-green-500 text-white">Save 17%</Badge>}
          </div>
        </div>

        {/* Main Pricing Plans */}
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto mb-16">
          {pricingPlans.map((plan, index) => (
            <Card
              key={index}
              className={`relative bg-gray-900/50 border backdrop-blur-sm hover:shadow-2xl transition-all duration-300 ${
                plan.popular ? "ring-2 ring-cyan-500 scale-105 border-cyan-500/50" : "border-gray-700/50"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-4 py-1">
                    Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl text-white mb-2">{plan.name}</CardTitle>
                <p className="text-gray-400 text-sm">{plan.description}</p>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-white">
                      ${isYearly ? plan.price.yearly : plan.price.monthly}
                    </span>
                    <span className="text-gray-400 ml-2">/{isYearly ? "year" : "month"}</span>
                  </div>
                  {isYearly && (
                    <div className="text-sm text-green-400 mt-1">
                      Save ${plan.price.monthly * 12 - plan.price.yearly} per year
                    </div>
                  )}
                </div>

                <Link href="/signup">
                  <Button
                    className={`w-full mb-6 ${
                      plan.popular
                        ? "bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                        : "bg-gray-700 hover:bg-gray-600"
                    }`}
                  >
                    Get Started
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>

                <div className="space-y-4">
                  <h4 className="font-semibold text-white">What's included:</h4>
                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-3">
                        <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-300 text-sm">{feature}</span>
                      </li>
                    ))}
                    {plan.notIncluded.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-3">
                        <X className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-500 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Add-On Services Toggle */}
        <div className="text-center mb-12">
          <Button
            onClick={() => setShowAddOns(!showAddOns)}
            variant="outline"
            className="border-cyan-400/50 text-cyan-400 hover:bg-cyan-400/10"
          >
            {showAddOns ? "Hide" : "Show"} DIY & DFY Add-Ons
            <ArrowRight className={`ml-2 w-4 h-4 transition-transform ${showAddOns ? "rotate-90" : ""}`} />
          </Button>
        </div>

        {/* Add-On Services */}
        {showAddOns && (
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-16">
            {addOnServices.map((addon, index) => (
              <Card key={index} className="bg-gray-900/50 border border-gray-700/50 backdrop-blur-sm">
                <CardHeader className="text-center">
                  <Badge className={`mb-2 ${addon.category === "diy" ? "bg-green-600" : "bg-blue-600"}`}>
                    {addon.category.toUpperCase()}
                  </Badge>
                  <CardTitle className="text-lg text-white">{addon.name}</CardTitle>
                  <p className="text-gray-400 text-sm">{addon.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="text-center mb-4">
                    <span className="text-2xl font-bold text-white">${addon.price}</span>
                    <span className="text-gray-400">/month</span>
                  </div>
                  <ul className="space-y-2 mb-6">
                    {addon.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-2 text-sm">
                        <Check className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href="/contact">
                    <Button
                      className={`w-full ${
                        addon.category === "diy" ? "bg-green-600 hover:bg-green-700" : "bg-blue-600 hover:bg-blue-700"
                      }`}
                    >
                      Add to Plan
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Learn More CTA */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 border border-cyan-500/20 rounded-2xl p-8 backdrop-blur-sm max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold text-white mb-4">Need Help Choosing?</h3>
            <p className="text-xl text-gray-300 mb-8">
              Our experts can help you find the perfect plan and add-ons for your business needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/learn-more">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                >
                  Learn More About All Options
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/business-loans">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-green-400/50 text-green-400 hover:bg-green-400/10"
                >
                  Business Funding Options
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
