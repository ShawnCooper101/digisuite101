"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Play, Pause, Volume2, VolumeX, CheckCircle, ArrowRight, Sparkles, Shield } from "lucide-react"

interface FormData {
  firstName: string
  lastName: string
  email: string
  phone: string
  company: string
  website: string
  monthlyRevenue: string
  marketingBudget: string
  primaryGoal: string
  currentChallenges: string
}

const videoScript = [
  {
    time: 0,
    duration: 15,
    text: "Hi! I'm Alex, your AI marketing assistant. Welcome to DigiMark101 - the most advanced AI-powered marketing platform.",
    scene: "intro",
    aiExpression: "greeting",
  },
  {
    time: 15,
    duration: 20,
    text: "Let me show you how our AI transforms businesses like yours. We've helped over 2,500 companies increase their ROI by an average of 347%.",
    scene: "stats",
    aiExpression: "explaining",
  },
  {
    time: 35,
    duration: 25,
    text: "First, our AI Lead Generation system automatically identifies and scores high-quality prospects. Watch as it analyzes visitor behavior in real-time.",
    scene: "lead-generation",
    aiExpression: "pointing",
  },
  {
    time: 60,
    duration: 25,
    text: "Next, our Email Marketing AI creates personalized campaigns that adapt to each customer's preferences. See how it optimizes send times and content automatically.",
    scene: "email-marketing",
    aiExpression: "demonstrating",
  },
  {
    time: 85,
    duration: 25,
    text: "Our Sales Funnel Builder uses AI to create high-converting funnels. It automatically tests different variations and optimizes for maximum conversions.",
    scene: "funnel-builder",
    aiExpression: "excited",
  },
  {
    time: 110,
    duration: 25,
    text: "Finally, our Analytics AI provides real-time insights and predictions. It tells you exactly what's working and what to optimize next.",
    scene: "analytics",
    aiExpression: "analytical",
  },
  {
    time: 135,
    duration: 25,
    text: "All of this is built on the proven allinonemarketing.com infrastructure, trusted by thousands of businesses worldwide.",
    scene: "platform",
    aiExpression: "confident",
  },
  {
    time: 160,
    duration: 20,
    text: "Ready to transform your marketing? Schedule your free custom demo today and see exactly how DigiMark101 can grow your business!",
    scene: "cta",
    aiExpression: "inviting",
  },
]

export function DemoLeadCaptureSection() {
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    website: "",
    monthlyRevenue: "",
    marketingBudget: "",
    primaryGoal: "",
    currentChallenges: "",
  })

  const [isPlaying, setIsPlaying] = useState(true) // Auto-play
  const [isMuted, setIsMuted] = useState(false)
  const [videoProgress, setVideoProgress] = useState(0)
  const [currentScript, setCurrentScript] = useState(videoScript[0])
  const [showForm, setShowForm] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  // Auto-play video progression
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPlaying) {
      interval = setInterval(() => {
        setVideoProgress((prev) => {
          const newProgress = prev + 1

          // Find current script segment
          const currentSegment = videoScript.find(
            (segment) => newProgress >= segment.time && newProgress < segment.time + segment.duration,
          )

          if (currentSegment && currentSegment !== currentScript) {
            setCurrentScript(currentSegment)
          }

          // Reset at end (3 minutes = 180 seconds)
          if (newProgress >= 180) {
            setIsPlaying(false)
            return 0
          }
          return newProgress
        })
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying, currentScript])

  // Auto-start video when component mounts
  useEffect(() => {
    setIsPlaying(true)
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Lead captured:", formData)
    setIsSubmitted(true)
  }

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getAICharacterStyle = (expression: string) => {
    const baseStyle = "transition-all duration-1000 ease-in-out"
    switch (expression) {
      case "greeting":
        return `${baseStyle} animate-wave`
      case "explaining":
        return `${baseStyle} animate-bounce-gentle`
      case "pointing":
        return `${baseStyle} animate-point-right`
      case "demonstrating":
        return `${baseStyle} animate-gesture`
      case "excited":
        return `${baseStyle} animate-excited`
      case "analytical":
        return `${baseStyle} animate-thinking`
      case "confident":
        return `${baseStyle} animate-confident`
      case "inviting":
        return `${baseStyle} animate-welcome`
      default:
        return baseStyle
    }
  }

  return (
    <section className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black py-20 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Sparkles className="w-6 h-6 text-cyan-400 animate-pulse" />
            <Badge className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-4 py-1">AI Video Demo</Badge>
          </div>

          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
            Meet Alex - Your{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
              AI Marketing Guide
            </span>
          </h1>

          <p className="text-xl text-gray-300 max-w-4xl mx-auto mb-8">
            Watch Alex demonstrate how DigiMark101's AI-powered platform transforms businesses like yours. Built on the
            proven <span className="text-cyan-400 font-semibold">allinonemarketing.com</span> infrastructure.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-7xl mx-auto">
          {/* AI Video Section */}
          <div className="space-y-6">
            {/* Main AI Video Player */}
            <Card className="bg-gray-900/50 border border-cyan-500/20 backdrop-blur-sm overflow-hidden">
              <div className="relative aspect-video bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20">
                {/* Replace the AI Character Section with Real Video */}
                {/* YouTube/Vimeo Embed */}
                <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                  <iframe
                    className="w-full h-full"
                    src="https://www.youtube.com/embed/YOUR_VIDEO_ID?autoplay=1&mute=1&controls=1"
                    title="DigiMark101 AI Marketing Demo"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>

                {/* Video Controls Overlay */}
                <div className="absolute inset-0 bg-black/20 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="flex items-center space-x-4">
                    <Button
                      size="lg"
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="bg-white/20 backdrop-blur-sm hover:bg-white/30 border border-white/30"
                    >
                      {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => setIsMuted(!isMuted)}
                      className="bg-white/20 backdrop-blur-sm hover:bg-white/30 border border-white/30"
                    >
                      {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 transition-all duration-1000"
                    style={{ width: `${(videoProgress / 180) * 100}%` }}
                  ></div>
                </div>

                {/* Time Display */}
                <div className="absolute bottom-2 left-2 text-white text-sm bg-black/50 px-2 py-1 rounded">
                  {formatTime(videoProgress)} / 3:00
                </div>

                {/* Live Indicator */}
                <div className="absolute top-4 left-4 flex items-center space-x-2 bg-red-500/80 backdrop-blur-sm px-3 py-1 rounded-full">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  <span className="text-white text-xs font-medium">LIVE AI DEMO</span>
                </div>
              </div>
            </Card>

            {/* Video Description */}
            <div className="bg-gray-900/30 border border-gray-700/50 rounded-lg p-4">
              <h3 className="text-white font-semibold mb-2">What Alex is showing you:</h3>
              <p className="text-gray-400 text-sm">{currentScript.text}</p>
              <div className="mt-3 flex items-center space-x-4 text-xs text-gray-500">
                <span>Scene: {currentScript.scene}</span>
                <span>•</span>
                <span>Duration: {currentScript.duration}s</span>
              </div>
            </div>

            {/* CTA to Show Form */}
            {!showForm && (
              <div className="text-center">
                <Button
                  size="lg"
                  onClick={() => setShowForm(true)}
                  className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 px-8 py-4"
                >
                  Get My Custom Demo with Alex
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <p className="text-gray-400 text-sm mt-2">Let Alex create a personalized demo for your business</p>
              </div>
            )}
          </div>

          {/* Lead Capture Form */}
          <div
            className={`transition-all duration-500 ${showForm ? "opacity-100" : "opacity-0 pointer-events-none lg:opacity-100 lg:pointer-events-auto"}`}
          >
            <Card className="bg-gray-900/50 border border-cyan-500/20 backdrop-blur-sm sticky top-24">
              <CardHeader>
                <CardTitle className="text-white text-2xl text-center">
                  {isSubmitted ? "Thank You!" : "Schedule Your Personal Demo with Alex"}
                </CardTitle>
                {!isSubmitted && (
                  <p className="text-gray-400 text-center">
                    Alex will create a custom demo specifically for your business
                  </p>
                )}
              </CardHeader>
              <CardContent>
                {isSubmitted ? (
                  <div className="text-center space-y-6">
                    <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle className="w-8 h-8 text-green-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">Demo Scheduled with Alex!</h3>
                      <p className="text-gray-400 mb-4">
                        Alex will contact you within 24 hours to schedule your personalized AI demo.
                      </p>
                      <div className="bg-cyan-900/30 border border-cyan-500/30 rounded-lg p-4">
                        <p className="text-cyan-300 text-sm">
                          <strong>What's Next with Alex:</strong>
                          <br />• Custom AI demo tailored to your business
                          <br />• ROI projection for your specific industry
                          <br />• Free marketing audit worth $500
                          <br />• Direct access to Alex for questions
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-300">First Name</Label>
                        <Input
                          value={formData.firstName}
                          onChange={(e) => handleInputChange("firstName", e.target.value)}
                          className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                          required
                        />
                      </div>
                      <div>
                        <Label className="text-gray-300">Last Name</Label>
                        <Input
                          value={formData.lastName}
                          onChange={(e) => handleInputChange("lastName", e.target.value)}
                          className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-gray-300">Business Email</Label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                        required
                      />
                    </div>

                    <div>
                      <Label className="text-gray-300">Phone Number</Label>
                      <Input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                        required
                      />
                    </div>

                    <div>
                      <Label className="text-gray-300">Company Name</Label>
                      <Input
                        value={formData.company}
                        onChange={(e) => handleInputChange("company", e.target.value)}
                        className="bg-gray-800 border-gray-600 text-white focus:border-cyan-400"
                        required
                      />
                    </div>

                    <div>
                      <Label className="text-gray-300">Monthly Revenue</Label>
                      <Select onValueChange={(value) => handleInputChange("monthlyRevenue", value)}>
                        <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                          <SelectValue placeholder="Select revenue range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="under-10k">Under $10K</SelectItem>
                          <SelectItem value="10k-50k">$10K - $50K</SelectItem>
                          <SelectItem value="50k-100k">$50K - $100K</SelectItem>
                          <SelectItem value="100k-500k">$100K - $500K</SelectItem>
                          <SelectItem value="500k-1m">$500K - $1M</SelectItem>
                          <SelectItem value="over-1m">Over $1M</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-gray-300">Primary Goal</Label>
                      <Select onValueChange={(value) => handleInputChange("primaryGoal", value)}>
                        <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                          <SelectValue placeholder="What's your main goal?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="increase-leads">Increase Leads</SelectItem>
                          <SelectItem value="boost-sales">Boost Sales</SelectItem>
                          <SelectItem value="improve-roi">Improve ROI</SelectItem>
                          <SelectItem value="automate-marketing">Automate Marketing</SelectItem>
                          <SelectItem value="scale-business">Scale Business</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 py-3"
                    >
                      Schedule My Demo with Alex AI
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>

                    <div className="text-center text-xs text-gray-500">
                      <p>
                        <Shield className="w-3 h-3 inline mr-1" />
                        Your information is secure and will never be shared
                      </p>
                      <p className="mt-1">
                        Powered by <span className="text-cyan-400">allinonemarketing.com</span>
                      </p>
                    </div>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 text-center">
          <div className="grid md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-cyan-400 mb-2">2,500+</div>
              <div className="text-gray-400">Businesses Transformed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-2">347%</div>
              <div className="text-gray-400">Average ROI Increase</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-400 mb-2">24/7</div>
              <div className="text-gray-400">AI-Powered Support</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">99.9%</div>
              <div className="text-gray-400">Platform Uptime</div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes wave {
          0%, 100% { transform: rotate(-5deg); }
          50% { transform: rotate(5deg); }
        }
        @keyframes bounce-gentle {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-5px); }
        }
        @keyframes point-right {
          0%, 100% { transform: translateX(0px); }
          50% { transform: translateX(10px); }
        }
        @keyframes gesture {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        @keyframes excited {
          0%, 100% { transform: scale(1) rotate(0deg); }
          25% { transform: scale(1.1) rotate(2deg); }
          75% { transform: scale(1.1) rotate(-2deg); }
        }
        @keyframes thinking {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-3px); }
        }
        @keyframes confident {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.02); }
        }
        @keyframes welcome {
          0%, 100% { transform: scale(1) rotate(0deg); }
          50% { transform: scale(1.05) rotate(1deg); }
        }
        @keyframes blink {
          0%, 90%, 100% { transform: scaleY(1); }
          95% { transform: scaleY(0.1); }
        }
        @keyframes talk {
          0%, 100% { transform: scaleY(1); }
          50% { transform: scaleY(1.5); }
        }
        @keyframes scan {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        @keyframes typewriter {
          from { width: 0; }
          to { width: 100%; }
        }
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scale-in {
          from { opacity: 0; transform: scale(0.8); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes slide-in-right {
          from { opacity: 0; transform: translateX(30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slide-in-left {
          from { opacity: 0; transform: translateX(-30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes progress-fill {
          from { width: 0%; }
          to { width: var(--target-width, 100%); }
        }
        @keyframes count-up {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes bar-grow {
          from { height: 0%; }
          to { height: var(--target-height, 50%); }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        .animate-wave { animation: wave 2s ease-in-out infinite; }
        .animate-bounce-gentle { animation: bounce-gentle 2s ease-in-out infinite; }
        .animate-point-right { animation: point-right 2s ease-in-out infinite; }
        .animate-gesture { animation: gesture 2s ease-in-out infinite; }
        .animate-excited { animation: excited 1s ease-in-out infinite; }
        .animate-thinking { animation: thinking 3s ease-in-out infinite; }
        .animate-confident { animation: confident 2s ease-in-out infinite; }
        .animate-welcome { animation: welcome 2s ease-in-out infinite; }
        .animate-blink { animation: blink 3s ease-in-out infinite; }
        .animate-talk { animation: talk 0.5s ease-in-out infinite; }
        .animate-scan { animation: scan 3s linear infinite; }
        .animate-typewriter { animation: typewriter 2s steps(40, end); }
        .animate-fade-in { animation: fade-in 0.8s ease-out; }
        .animate-scale-in { animation: scale-in 0.6s ease-out; }
        .animate-slide-in-right { animation: slide-in-right 0.8s ease-out; }
        .animate-slide-in-left { animation: slide-in-left 0.8s ease-out; }
        .animate-progress-fill { animation: progress-fill 2s ease-out; }
        .animate-count-up { animation: count-up 1s ease-out; }
        .animate-bar-grow { animation: bar-grow 1.5s ease-out; }
        .animate-spin-slow { animation: spin-slow 4s linear infinite; }
      `}</style>
    </section>
  )
}
